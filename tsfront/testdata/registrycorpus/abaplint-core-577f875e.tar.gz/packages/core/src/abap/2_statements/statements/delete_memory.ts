import {IStatement} from "./_statement";
import {verNotLang, seq, alt, optPrio, altPrio, regex} from "../combi";
import {Source, Field} from "../expressions";
import {LanguageVersion} from "../../../version";
import {IStatementRunnable} from "../statement_runnable";

export class DeleteMemory implements IStatement {

  public getMatcher(): IStatementRunnable {
    const memory = seq("MEMORY ID", Source);

    const id = seq("ID", Source);
    const client = seq("CLIENT", Source);
    const shared = seq("SHARED", altPrio("MEMORY", "BUFFER"), Field, "(", regex(/^[\w%]+$/), ")", optPrio(client), id);

    const ret = seq("DELETE FROM", alt(memory, shared));

    return verNotLang(LanguageVersion.Cloud, ret);
  }

}
