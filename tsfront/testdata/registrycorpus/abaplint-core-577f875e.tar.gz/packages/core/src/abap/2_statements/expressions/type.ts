import {seq, optPrio, Expression, altPrio, ver} from "../combi";
import {TypeName, Default, FieldChain, LOBHandle, ComponentName} from ".";
import {IStatementRunnable} from "../statement_runnable";
import {Release} from "../../../version";

export class Type extends Expression {
  public getRunnable(): IStatementRunnable {

    const indicatorSpec = altPrio(ver(Release.v784, "AS BITFIELD"), seq("TYPE", TypeName));
    const indicators = seq("WITH INDICATORS", ComponentName, optPrio(indicatorSpec));

    const typeType = seq(TypeName, optPrio(Default));

    const like = altPrio(seq("LINE OF", FieldChain),
                         seq("REF TO", FieldChain),
                         FieldChain);

    const type = altPrio(seq("LINE OF", typeType),
                         seq("REF TO", typeType),
                         seq(typeType, optPrio(LOBHandle)));

    const ret = seq(altPrio(seq("LIKE", like), seq("TYPE", type)), optPrio(ver(Release.v781, indicators)));

    return ret;
  }
}